title_text = [120, 40]

class Title():
    new_game_button = [1040, 560, 160, 80]
    load_game_button = [1040, 640, 160, 80]
