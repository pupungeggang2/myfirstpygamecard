import pygame

pygame.font.init()

class Font():
    title = pygame.font.SysFont('Arial', 60)

class Color():
    black = (0, 0, 0)
    white = (255, 255, 255)
