import var

def start_title():
    var.scene = 'title'

def start_field():
    var.scene = 'field'
